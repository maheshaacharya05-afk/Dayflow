# Dayflow — Android project

A dark, premium-style daily task manager built with Kotlin and Jetpack Compose.

## Included
- Add, complete, and delete tasks
- Task time, category, and priority
- Daily progress bar and All/Open/Done filters
- Local persistence on the phone (DataStore)
- No reminders, alarms, or notifications

## Build an APK
1. Install Android Studio on a computer.
2. Open this `DayflowAndroid` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Use **Locate** in the build notification to find the APK.

This is the Android project source, not a precompiled APK. A computer with Android Studio is needed to compile it.
