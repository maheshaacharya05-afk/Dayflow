# Build Dayflow APK using only an Android phone

This project includes a GitHub Actions workflow that builds an installable debug APK in the cloud. No computer or Android Studio is needed, but a GitHub account is required.

## Important
The ZIP is Android source code, not the APK itself. The APK is created after the project is uploaded to a GitHub repository and the workflow finishes.

## Phone-only route
1. Download and extract `DayflowAndroid_Project.zip` using your phone's Files app.
2. Sign in to GitHub in Chrome and create a new **public** repository named `DayflowAndroid` (a private repo can work too if your account allows Actions).
3. Open the repository in Chrome. Turn on **Desktop site** if needed.
4. Use **Add file → Upload files** and upload the contents of the extracted `DayflowAndroid` folder, including the hidden `.github/workflows/build-apk.yml` file. If your phone's file picker cannot show hidden files or preserve folders, use a file manager that can show hidden files, or tell me and I'll walk you through an alternative.
5. Commit the files to the `main` branch.
6. Open the repository's **Actions** tab and select **Build Dayflow APK**. If it is not listed, open the workflow and tap **Run workflow**.
7. Wait for the workflow to finish successfully. Open the completed run and download the **Dayflow-debug-APK** artifact.
8. Extract the downloaded artifact ZIP, tap `app-debug.apk`, and approve Android's “Install unknown apps” permission for the browser or file manager if Android asks.

Only install the APK built from your own repository. A debug APK is suitable for personal testing; it is not a Play Store release.
