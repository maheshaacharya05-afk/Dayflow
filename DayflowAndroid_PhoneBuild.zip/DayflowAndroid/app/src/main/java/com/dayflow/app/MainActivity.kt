package com.dayflow.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val ComponentActivity.dataStore by preferencesDataStore(name = "dayflow_store")

private val Bg = Color(0xFF0B0D12)
private val Panel = Color(0xFF151923)
private val Panel2 = Color(0xFF1C2230)
private val Accent = Color(0xFF9B8CFF)
private val TextMain = Color(0xFFF3F4F8)
private val TextMuted = Color(0xFF9299AA)
private val Green = Color(0xFF5DDBA0)

data class TaskItem(
    val id: Long,
    val title: String,
    val time: String,
    val category: String,
    val priority: String,
    val done: Boolean,
    val day: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DayflowApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DayflowApp(activity: ComponentActivity) {
    val scope = rememberCoroutineScope()
    val key = stringPreferencesKey("tasks_json")
    var tasks by remember { mutableStateOf(listOf<TaskItem>()) }
    var showAdd by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("09:00") }
    var category by remember { mutableStateOf("Study") }
    var priority by remember { mutableStateOf("Medium") }
    var filter by remember { mutableStateOf("All") }
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    val dateLabel = remember { SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()) }

    fun save(list: List<TaskItem>) {
        tasks = list
        scope.launch {
            val array = JSONArray()
            list.forEach {
                array.put(JSONObject().apply {
                    put("id", it.id); put("title", it.title); put("time", it.time)
                    put("category", it.category); put("priority", it.priority)
                    put("done", it.done); put("day", it.day)
                })
            }
            activity.dataStore.edit { prefs -> prefs[key] = array.toString() }
        }
    }

    LaunchedEffect(Unit) {
        val raw = activity.dataStore.data.first()[key] ?: "[]"
        val arr = JSONArray(raw)
        tasks = (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            TaskItem(o.optLong("id"), o.optString("title"), o.optString("time"),
                o.optString("category", "Study"), o.optString("priority", "Medium"),
                o.optBoolean("done"), o.optString("day", today))
        }
    }

    val todays = tasks.filter { it.day == today }
    val completed = todays.count { it.done }
    val shown = todays.filter { when(filter) { "Open" -> !it.done; "Done" -> it.done; else -> true } }
        .sortedWith(compareBy<TaskItem> { it.done }.thenBy { it.time })

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, background = Bg, surface = Panel,
            onBackground = TextMain, onSurface = TextMain
        )
    ) {
        Scaffold(
            containerColor = Bg,
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { showAdd = true },
                    containerColor = Accent,
                    contentColor = Bg,
                    shape = RoundedCornerShape(18.dp)
                ) { Icon(Icons.Default.Add, contentDescription = "Add task") }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp)
                    .padding(top = 18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(44.dp).background(Accent.copy(alpha = .16f), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.TaskAlt, null, tint = Accent, modifier = Modifier.size(25.dp)) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("DAYFLOW", fontSize = 12.sp, letterSpacing = 2.sp, color = Accent, fontWeight = FontWeight.Bold)
                        Text("Your day, in focus.", fontSize = 14.sp, color = TextMuted)
                    }
                    Icon(Icons.Default.CalendarMonth, null, tint = TextMuted)
                }
                Spacer(Modifier.height(28.dp))
                Text("Today", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = TextMain)
                Text(dateLabel, fontSize = 14.sp, color = TextMuted)
                Spacer(Modifier.height(20.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("DAILY PROGRESS", fontSize = 11.sp, color = TextMuted, letterSpacing = 1.5.sp)
                                Spacer(Modifier.height(6.dp))
                                Text("$completed of ${todays.size} tasks complete", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Text(if (todays.isEmpty()) "0%" else "${completed * 100 / todays.size}%",
                                color = Accent, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                        }
                        Spacer(Modifier.height(14.dp))
                        LinearProgressIndicator(
                            progress = { if (todays.isEmpty()) 0f else completed.toFloat() / todays.size },
                            modifier = Modifier.fillMaxWidth().height(7.dp),
                            color = Accent, trackColor = Panel2
                        )
                    }
                }
                Spacer(Modifier.height(24.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Your tasks", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("${shown.size} items", color = TextMuted, fontSize = 13.sp)
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("All", "Open", "Done").forEach { item ->
                        val selected = filter == item
                        Surface(
                            color = if (selected) Accent else Panel,
                            shape = RoundedCornerShape(50),
                            modifier = Modifier.clickable { filter = item }
                        ) {
                            Text(item, color = if (selected) Bg else TextMuted,
                                modifier = Modifier.padding(horizontal = 18.dp, vertical = 9.dp),
                                fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                if (shown.isEmpty()) {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("✦", fontSize = 34.sp, color = Accent)
                            Spacer(Modifier.height(8.dp))
                            Text(if (todays.isEmpty()) "A fresh start." else "You're all caught up!",
                                fontWeight = FontWeight.SemiBold, fontSize = 19.sp)
                            Text(if (todays.isEmpty()) "Tap + to add your first task." else "Nothing in this filter.",
                                color = TextMuted, fontSize = 14.sp)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(bottom = 90.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(shown, key = { it.id }) { task ->
                            TaskCard(
                                task = task,
                                onToggle = { save(tasks.map { if (it.id == task.id) it.copy(done = !it.done) else it }) },
                                onDelete = { save(tasks.filterNot { it.id == task.id }) }
                            )
                        }
                    }
                }
            }
        }

        if (showAdd) {
            AlertDialog(
                onDismissRequest = { showAdd = false },
                containerColor = Panel,
                title = { Text("Add a task", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(value = title, onValueChange = { title = it },
                            label = { Text("Task name") }, singleLine = true)
                        OutlinedTextField(value = time, onValueChange = { time = it },
                            label = { Text("Time (e.g. 09:30)") }, singleLine = true)
                        Text("Category", color = TextMuted, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Study", "Personal", "Other").forEach {
                                FilterChip(selected = category == it, onClick = { category = it }, label = { Text(it) })
                            }
                        }
                        Text("Priority", color = TextMuted, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Low", "Medium", "High").forEach {
                                FilterChip(selected = priority == it, onClick = { priority = it }, label = { Text(it) })
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (title.isNotBlank()) {
                            save(tasks + TaskItem(System.currentTimeMillis(), title.trim(), time.trim(),
                                category, priority, false, today))
                            title = ""; time = "09:00"; category = "Study"; priority = "Medium"
                            showAdd = false
                        }
                    }) { Text("Add task") }
                },
                dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } }
            )
        }
    }
}

@Composable
fun TaskCard(task: TaskItem, onToggle: () -> Unit, onDelete: () -> Unit) {
    val priorityColor = when (task.priority) {
        "High" -> Color(0xFFFF7C8A)
        "Low" -> Green
        else -> Accent
    }
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(28.dp).background(if (task.done) Green else Panel2, CircleShape)
                    .clickable { onToggle() },
                contentAlignment = Alignment.Center
            ) {
                if (task.done) Icon(Icons.Default.Check, null, tint = Bg, modifier = Modifier.size(17.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(task.title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    color = if (task.done) TextMuted else TextMain,
                    textDecoration = if (task.done) TextDecoration.LineThrough else TextDecoration.None)
                Spacer(Modifier.height(5.dp))
                Text("${task.time}  •  ${task.category}", fontSize = 12.sp, color = TextMuted)
                Spacer(Modifier.height(7.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(6.dp).background(priorityColor, CircleShape))
                    Spacer(Modifier.width(5.dp))
                    Text("${task.priority} priority", color = priorityColor, fontSize = 11.sp)
                }
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete task", tint = TextMuted)
            }
        }
    }
}
